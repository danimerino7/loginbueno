//
//  ViewController.swift
//  login_swift
//
//  Created by A4-iMAC03 on 30/11/2020.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var usuario: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var erroruser: UILabel!
    @IBOutlet weak var wrongpass: UILabel!
    @IBOutlet weak var registrado: UILabel!
    
  let defaults = UserDefaults.standard
    
    var acceso = 0;
    
    


    override func viewDidLoad() {
        super.viewDidLoad()
      
       let register = defaults.string(forKey: "registrado")
        let pass = defaults.string(forKey: "password")
        let user = defaults.string(forKey: "usuario")
        let respuesta = defaults.integer(forKey: "respuesta")
        
        
        usuario.text = user
        password.text = ""
        
        if register != "" {
            logueo() //logueo automatico si el usuario esta registrado al iniciar la app
            NSLog("Ultimo usuario registrado :\(register ?? "sin registro")")
            NSLog("Contraseña :  \(pass ?? "sin registro")")
            NSLog("usuario : \(user ?? "sin registro")")
            
        }
    
    }
    
    //select de ciclos
    @IBAction func seleccion(_ sender: Any) {
        
        if  (sender as! UISegmentedControl).selectedSegmentIndex == 0 {
            NSLog("primero")
        }else if (sender as! UISegmentedControl).selectedSegmentIndex == 1 {
            NSLog("segundo")
        }else{
            NSLog("tercero")
        }
    }  //fin select de ciclos
    
    //click login
    @IBAction func login(_ sender: Any) {
        
            //si el campo esta vacio aparece error de campo hidden
        if  usuario.text == "" {
            erroruser.isHidden = false
            erroruser.text = "*usuario obligatorio"
            
        }else {
            //Si no, se guarda el campo usuario en el user default y desaparece el campo error
            defaults.setValue(usuario.text, forKey: "usuario")
            erroruser.isHidden = true
        }
        
        //igual pero con la contraseña + funcion loguin
        if password.text == "" {
            wrongpass.text = "*pass obligatoria"
            wrongpass.isHidden = false
        }else {
            
           
            defaults.setValue(password.text, forKey: "password")
            wrongpass.isHidden = true
            post()
            
            //ZONA DE TESTEO NO ENTRA
            if usuario.text != "" && password.text != "" && defaults.integer(forKey: "respuesta") == 1  {
                
                //aqui falta la comprobacion, entra siempre
    
                if acceso == 1 {
                    print("logueando")
                }
                
            }
        }
        
        
    }
    
    
    //funcion para cambiar la actividad desde la navegacion raiz
    func logueo () {
        
        var _ =  UIStoryboard(name:"Main",bundle: nil)
        let segunda = storyboard?.instantiateViewController(identifier: "second") as! vista2
        navigationController?.pushViewController(segunda, animated: false)
    }
    
    //inicio post
    func post(){
        //para enviar los datos a la api
        let Url = String(format: "https://qastusoft.com.es/apis/login2.php")
        guard let serviceUrl = URL(string: Url) else { return }
        var request = URLRequest(url: serviceUrl)
        request.httpMethod = "POST"
        request.setValue("Application/x-www-form-urlencoded", forHTTPHeaderField: "Content-Type")

        let bodyData = "user=\(defaults.string(forKey: "usuario"))&pass=\(defaults.string(forKey: "password"))."
        request.httpBody = bodyData.data(using: String.Encoding.utf8);

        let session = URLSession.shared
        session.dataTask(with: request) { [self] (data, response, error) in
            if let response = response {
                print(response)
            }
            if let data = data {
                
                do {
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
                    print(json)
                    
                 //   print(json["code"])
                    
                    json["code"] as! Int
                    
                    switch json["code"] as! Int {
                    case 1:
                        print("acceso ok")
                        acceso = json["code"] as! Int
                        
                    case -1:
                        print("\(acceso)faltan datos")
                    case -2:
                        print("\(acceso)Credenciales no válidas")
                    case -3:
                        print("\(acceso)Ciclo no válido")
                    default:
                        print("\(acceso)no se ha podido loguear")
                    }
                  
    
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
    //fin post
    
}

